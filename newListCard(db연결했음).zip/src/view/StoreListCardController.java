package view;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.DBConnect;
import model.Restaurant;
import model.Store;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

public class StoreListCardController implements Initializable {
	@FXML
	private Pane restauranticon;

	@FXML
	private Pane cafeicon;

	@FXML
	private Pane storeicon;

	@FXML
	private TextField searchBar;

	@FXML
	private ScrollPane scroll;

	@FXML
	private VBox shopBox;

	@FXML
	private ImageView imgSearch;

	@FXML
	void cafeClick(MouseEvent event) throws IOException {
		cafeicon.getScene().getWindow().hide();

		Stage viewCafe = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("../view/CafeListCard.fxml"));
		Scene scene = new Scene(root);
		viewCafe.setTitle("ī�� ����Ʈī��");
		viewCafe.setScene(scene);
		viewCafe.show();
	}

	@FXML
	void reatuarantClick(MouseEvent event) throws IOException {
		restauranticon.getScene().getWindow().hide();

		Stage viewRestaurant = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("../view/RestaurantListCard.fxml"));
		Scene scene = new Scene(root);
		viewRestaurant.setTitle("������� ����Ʈī��");
		viewRestaurant.setScene(scene);
		viewRestaurant.show();
	}

	
	DBConnect connect = new DBConnect();
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		List<Store> list = stores();
		for (int i = 0; i < list.size(); i++) {
			FXMLLoader fxmlLoader = new FXMLLoader();
			fxmlLoader.setLocation(getClass().getResource("Store.fxml"));

			try {
				HBox hbox = fxmlLoader.load();
				StoreController sic = fxmlLoader.getController();
				sic.setData(list.get(i));

				shopBox.getChildren().add(hbox);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private List<Store> stores() {
		List<Store> st = new ArrayList<>();

		Store store;
		String sql = "SELECT name, address, tel, time, img FROM market WHERE cateid = 3";

		Connection conn = connect.getConnection();
		Statement stmt;
		ResultSet rs;

		try {
			stmt = conn.createStatement(); // ������ü ����
			rs = stmt.executeQuery(sql); // sql������ �־ �����ϰ� ����� rs�� ��ƿ�

			while (rs.next()) {
				store = new Store(rs.getString("NAME"), rs.getString("ADDRESS"), rs.getString("TEL"),
						rs.getString("TIME"), rs.getString("IMG"));
				st.add(store);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return st;

	}

//	 private List<Store> stores(){
//		 List<Store> ss = new ArrayList<>();
//		 Store store = new Store();
//		 
//		 store.setName("GS25 ����������");
//		 store.setImgSrc("../img/GS25.jpg");
//		 store.setInfo("�λ� �λ����� �߾Ӵ��680���� 45-9\r\n"
//         		+ "051-818-2478\r\n"
//         		+ "����");
//         ss.add(store);
//         
//         store = new Store();
//         store.setName("�̸�Ʈ24 �������Ÿ����");
//		 store.setImgSrc("../img/emart24.jpg");
//		 store.setInfo("�λ� �λ����� �߾Ӵ�� 672\r\n"
//         		+ "051-520-3773\r\n"
//         		+ "���� 10:00 - 02:00");
//         ss.add(store);
//         
//         store = new Store();
//         store.setName("�����Ϸ��� �λ�и�������");
//		 store.setImgSrc("../img/�����Ϸ���.jpg");
//		 store.setInfo("�λ� �λ����� ������ 25 �̿���������\r\n"
//         		+ "051-817-3372\r\n"
//         		+ "����");
//         ss.add(store);
//         
//         store = new Store();
//         store.setName("CU �ξ���");
//		 store.setImgSrc("../img/CU.jpg");
//		 store.setInfo("�λ� �λ����� ��õ��� 204\r\n"
//         		+ "051-808-3328\r\n"
//         		+ "����");
//         ss.add(store);
//         
//         store = new Store();
//         store.setName("GS25 ����������");
//		 store.setImgSrc("../img/GS25.jpg");
//		 store.setInfo("�λ� �λ����� ��õ�� 72\r\n"
//         		+ "051-818-9866\r\n"
//         		+ "����");
//         ss.add(store);
//         
//         store = new Store();
//         store.setName("CU ���鼾Ʈ����Ÿ��");
//		 store.setImgSrc("../img/CU.jpg");
//		 store.setInfo("�λ� �λ����� ��õ���50���� 34\r\n"
//         		+ "051-802-7434\r\n"
//         		+ "����");
//         ss.add(store);
//         
//
//         return ss;
//         
//	 }
}
