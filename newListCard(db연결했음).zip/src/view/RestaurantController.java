package view;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import model.Restaurant;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class RestaurantController implements Initializable{
	
    @FXML
    private HBox cardList;

    @FXML
    private ImageView img;

    @FXML
    private Label shopName;

    @FXML
    private Label shopAddress;

    @FXML
    private Label shopTel;

    @FXML
    private Label shopOpenHours;


	public void setData(Restaurant restaurant) {

//		Image shopImg = new Image(getClass().getResourceAsStream(cafe.getImgSrc()));
//	    img.setImage(shopImg);
	    shopName.setText(restaurant.getName());
	    shopAddress.setText(restaurant.getAddress());
	    shopTel.setText(restaurant.getTel());
	    shopOpenHours.setText(restaurant.getOpenhours());
	    }
	
	  
	 @FXML
	    void mouseClick(MouseEvent event) throws IOException {
		 	cardList.getScene().getWindow().hide();
		 
		    Stage viewReview = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("../view/.fxml"));
			Scene scene = new Scene(root);
			viewReview.setTitle("���亸��");
			viewReview.setScene(scene);
			viewReview.show();
		
	    }
	 
		@Override
		public void initialize(URL location, ResourceBundle resources) {
					
		}

}