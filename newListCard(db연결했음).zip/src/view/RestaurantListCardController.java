package view;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.DBConnect;
import model.Restaurant;

public class RestaurantListCardController implements Initializable {

    @FXML
    private Pane restauranticon;

    @FXML
    private Pane cafeicon;

    @FXML
    private Pane storeicon;

    @FXML
    private TextField searchBar;

    @FXML
    private ScrollPane scroll;

    @FXML
    private VBox shopBox;

    @FXML
    private ImageView imgSearch;
    
    @FXML
    void cafeClick(MouseEvent event) throws IOException {
    	cafeicon.getScene().getWindow().hide();
		 
	    Stage viewCafe = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("../view/CafeListCard.fxml"));
		Scene scene = new Scene(root);
		viewCafe.setTitle("������ ����Ʈī��");
		viewCafe.setScene(scene);
		viewCafe.show();
    }

    @FXML
    void storeClick(MouseEvent event) throws IOException {
    	storeicon.getScene().getWindow().hide();
		 
	    Stage viewStore = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("../view/StoreListCard.fxml"));
		Scene scene = new Scene(root);
		viewStore.setTitle("������ ����Ʈī��");
		viewStore.setScene(scene);
		viewStore.show();
    }

	DBConnect connect = new DBConnect();
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		List<Restaurant> list = restaurants();
		for (int i = 0; i < list.size(); i++) {
			FXMLLoader fxmlLoader = new FXMLLoader();
			fxmlLoader.setLocation(getClass().getResource("Restaurant.fxml"));

			try {
				HBox hbox = fxmlLoader.load();
				RestaurantController cic = fxmlLoader.getController();
				cic.setData(list.get(i));

				shopBox.getChildren().add(hbox);
			} catch (IOException e) {
				System.out.println("������");
			}
		}
	}

	private List<Restaurant> restaurants() {
		List<Restaurant> rt = new ArrayList<>();

		Restaurant restaurant;
		String sql = "SELECT name, address, tel, time, img FROM market WHERE cateid = 1";

		Connection conn = connect.getConnection();
		Statement stmt;
		ResultSet rs;

		try {
			stmt = conn.createStatement(); // ������ü ����
			rs = stmt.executeQuery(sql); // sql������ �־ �����ϰ� ����� rs�� ��ƿ�

			while (rs.next()) {
				restaurant = new Restaurant(rs.getString("NAME"), rs.getString("ADDRESS"), rs.getString("TEL"),
						rs.getString("TIME"), rs.getString("IMG"));
				rt.add(restaurant);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rt;

	}

//	 private List<Restaurant> restaurants(){
//		 List<Restaurant> rs = new ArrayList<>();
//		 Restaurant restaurant = new Restaurant();
//		 
//		 restaurant.setName("�������");
//		 restaurant.setImgSrc("../img/�������.jpg");
//		 restaurant.setInfo("�λ� �λ����� �߾Ӵ��680������ 80-30\r\n"
//         		+ "051-807-0377\r\n"
//         		+ "���� 17:30 - 03:00");
//         rs.add(restaurant);
//         
//         restaurant = new Restaurant();
//         restaurant.setName("���̼���");
//		 restaurant.setImgSrc("../img/���̼���.jpg");
//		 restaurant.setInfo("�λ� �λ����� ������46���� 6\r\n"
//         		+ "0507-1369-9399\r\n"
//         		+ "���� 11:30 - 20:30");
//         rs.add(restaurant);
//         
//         restaurant = new Restaurant();
//         restaurant.setName("3found");
//		 restaurant.setImgSrc("../img/3found.jpg");
//		 restaurant.setInfo("�λ� �λ����� ������ 50\r\n"
//         		+ "0507-1330-8853\r\n"
//         		+ "���� 11:00 - 21:30");
//         rs.add(restaurant);
//         
//         restaurant = new Restaurant();
//         restaurant.setName("ȭ������������");
//		 restaurant.setImgSrc("../img/ȭ������������.jpg");
//		 restaurant.setInfo("�λ� �λ����� �߾Ӵ��680������ 80-30\r\n"
//         		+ "051-807-0377\r\n"
//         		+ "���� 17:30 - 03:00");
//         rs.add(restaurant);
//         
//         restaurant = new Restaurant();
//         restaurant.setName("ī���ͽĴ�");
//		 restaurant.setImgSrc("../img/ī���ͽĴ�.jpg");
//		 restaurant.setInfo("������ 8�� �ⱸ �λ����� Ⱦ�ܺ��� �ǳ��� 1��\r\n"
//         		+ "0507-1308-6106\r\n"
//         		+ "���� 00:00 - 00:01");
//         rs.add(restaurant);
//         
//         restaurant = new Restaurant();
//         restaurant.setName("���ż�");
//		 restaurant.setImgSrc("../img/���ż�.jpg");
//		 restaurant.setInfo("�λ� �λ����� ��õ��108���� 11\r\n"
//         		+ "051-911-4960\r\n"
//         		+ "���� 11:30 - 21:00");
//         rs.add(restaurant);
//                                    
//         return rs;
//         
//	 }
}
