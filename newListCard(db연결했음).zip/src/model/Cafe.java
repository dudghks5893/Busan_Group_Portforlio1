package model;

public class Cafe {
    private String name;
    private String imgSrc;
    private String address;
    private String tel;
    private String openhours;
    
    public Cafe(String name, String imgSrc, String address, String tel, String openhours) {

		this.name = name;
		this.imgSrc = imgSrc;
		this.address = address;
		this.tel = tel;
		this.openhours = openhours;
	}

	public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImgSrc() {
        return imgSrc;
    }

    public void setImgSrc(String imgSrc) {
        this.imgSrc = imgSrc;
    }

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getOpenhours() {
		return openhours;
	}

	public void setOpenhours(String openhours) {
		this.openhours = openhours;
	}



    
}
