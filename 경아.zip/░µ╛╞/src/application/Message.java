package application;

import javafx.scene.control.Alert;

public class Message{
	public void setMessage(String gogo)
	{
		Alert alert = new Alert(Alert.AlertType.WARNING);
		alert.setTitle("�α���");
		alert.setHeaderText("");
		alert.setContentText(gogo);
		alert.show();
	}
}


