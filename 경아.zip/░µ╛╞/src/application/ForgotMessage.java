package application;

import javafx.scene.control.Alert;

public class ForgotMessage {
	public void setMessage(String gogo)
	{
		Alert alert = new Alert(Alert.AlertType.WARNING);
		alert.setTitle("���̵�/��й�ȣ ã��");
		alert.setHeaderText("");
		alert.setContentText(gogo);
		alert.show();
	}
}
