package view;



import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;

import application.Message;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.DBConnect;

public class UserLoginController{

    @FXML
    private Pane LoginPane;

	@FXML
    private JFXTextField UserId;

	@FXML
    private JFXPasswordField UserPw;


    @FXML
    private JFXButton UserLogin;


    @FXML
    private JFXButton SignUp;

    @FXML
    private Label UserResult;

    Message msg = new Message();
    DBConnect connect = new DBConnect();
    Connection conn;
    PreparedStatement pstmt;
    ResultSet rs;


    @FXML
    void SaveAccountCheck(ActionEvent event) {

    }

    @FXML
    void SignUpBtn(ActionEvent event) throws IOException {
    	SignUp.getScene().getWindow().hide();
    	Stage signup = new Stage();
    	Parent root = FXMLLoader.load(getClass().getResource("../view/UserSignUp.fxml"));
    	Scene scene = new Scene(root);
    	signup.setScene(scene);
    	signup.setTitle("ȸ�� ����");
    	signup.show();
    }
    
    

    @FXML
    void UserLoginBtn(ActionEvent event) throws IOException, SQLException{
    	conn = connect.getConnection();
    	
    	String sql = "SELECT * FROM customer WHERE id=? AND password=?";
    	
    	pstmt = conn.prepareStatement(sql);
    	pstmt.setString(1, UserId.getText());
    	pstmt.setString(2, UserPw.getText());
    	rs = pstmt.executeQuery();
    	
    	if(rs.next()) {
//    		msg.setMessage("Welcome");
    		//���� â�� �ݴ´�
    		UserLogin.getScene().getWindow().hide();
    		//�� Ȩ������ ȭ���� ����
    		Stage cate = new Stage();
        	Parent root = FXMLLoader.load(getClass().getResource("../view/Category.fxml"));
        	Scene scene = new Scene(root);
        	cate.setScene(scene);
        	cate.show();
    		
    	}
    	else if((UserId.getText().equals("")) && UserPw.getText().equals("")){
    		msg.setMessage("�α��� ������ �Է��� �ּ���.");
    	}
    	
    	else if(UserPw.getText().equals("")){
    		msg.setMessage("��й�ȣ�� �Է��� �ּ���.");
    	}
    	else {
    		msg.setMessage("�̸��ϰ� �н����带 ��Ȯ���Ͻʽÿ�.");
    	}


    }



	}


