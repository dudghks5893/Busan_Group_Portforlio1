package view;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.DBConnect;
import model.Store;

public class StoreListCardController implements Initializable {
	@FXML
	private Pane restauranticon;

	@FXML
	private Pane cafeicon;

	@FXML
	private Pane storeicon;

	@FXML
	private TextField searchBar;

	@FXML
	private ScrollPane scroll;

	@FXML
	private VBox shopBox;

	@FXML
	private ImageView imgSearch;

	@FXML
	void restaurantClick(MouseEvent event) throws IOException {
		restauranticon.getScene().getWindow().hide();

		Stage viewRestaurant = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("RestaurantListCard.fxml"));
		Scene scene = new Scene(root);
		viewRestaurant.setTitle("������� ����Ʈī��");
		viewRestaurant.setScene(scene);
		viewRestaurant.show();
	}

	@FXML
	void cafeClick(MouseEvent event) throws IOException {
		cafeicon.getScene().getWindow().hide();

		Stage viewCafe = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("CafeListCard.fxml"));
		Scene scene = new Scene(root);
		viewCafe.setTitle("ī�� ����Ʈī��");
		viewCafe.setScene(scene);
		viewCafe.show();
	}

	DBConnect connect = new DBConnect();
	Connection conn;
	PreparedStatement pstmt;
	ResultSet rs;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		List<Store> list = stores();
		for (int i = 0; i < list.size(); i++) {
			FXMLLoader fxmlLoader = new FXMLLoader();
			fxmlLoader.setLocation(getClass().getResource("Store.fxml"));

			try {
				HBox hbox = fxmlLoader.load();
				StoreController cic = fxmlLoader.getController();
				cic.setData(list.get(i));

				shopBox.getChildren().add(hbox);
			} catch (IOException e) {
				System.out.println("������");
			}
		}
	}

	private List<Store> stores() {
		List<Store> cf = new ArrayList<>();

		Store store;
		String sql = "SELECT name, address, tel, time, img FROM market WHERE cateid = 3";

		Connection conn = connect.getConnection();
		Statement stmt;
		ResultSet rs;

		try {
			stmt = conn.createStatement(); // ������ü ����
			rs = stmt.executeQuery(sql); // sql������ �־ �����ϰ� ����� rs�� ��ƿ�

			while (rs.next()) {
				store = new Store(rs.getString("NAME"), rs.getString("ADDRESS"), rs.getString("TEL"),
						rs.getString("TIME"), rs.getString("IMG"));
				cf.add(store);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cf;

	}

}
