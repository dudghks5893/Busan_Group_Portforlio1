package view;

import java.io.IOException;


import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;

import application.ForgotMessage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ForgotAccountController {

    @FXML
    private JFXTextField ForgotTel;

    @FXML
    private JFXTextField ForgotName;

    @FXML
    private JFXButton ForgotResult;
    ForgotMessage msg = new ForgotMessage();

    @FXML
    private JFXButton ForgotBack;

    @FXML
    void ForgotBackBtn(ActionEvent event) throws IOException {
    	ForgotBack.getScene().getWindow().hide();
    	Stage forgotback = new Stage();
    	Parent root = FXMLLoader.load(getClass().getResource("../view/UserLogin.fxml"));
    	Scene scene = new Scene(root);
    	forgotback.setScene(scene);
    	forgotback.setTitle("�ڷγ� ���� ���� ���α׷�");
    	forgotback.show();
    }

    @FXML
    void ForgotResultBtn(ActionEvent event) throws IOException {
    	if((ForgotName.getText().equals("")) && ForgotTel.getText().equals("")){
    		msg.setMessage("��� �Է��� �ּ���.");
    	}
    	else if(ForgotName.getText().equals("")){
    		msg.setMessage("�̸��� �Է��� �ּ���.");
    	}
    	else if(ForgotTel.getText().equals("")){
    		msg.setMessage("��ȭ��ȣ�� �Է��� �ּ���.");
    	}
    	}
    }


