package model;

public class Cafe {
    private String name;
    private String address; 
    private String tel; 
    private String openhours; 
    private String imgSrc;
    
    public Cafe(String name, String address, String tel, String openhours,  String imgSrc) {

		this.name = name;
		this.address = address;
		this.tel = tel;
		this.openhours = openhours;
		this.imgSrc = imgSrc;
	}

	public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getOpenhours() {
		return openhours;
	}

	public void setOpenhours(String openhours) {
		this.openhours = openhours;
	}
	public String getImgSrc() {
	        return imgSrc;
	}

	public void setImgSrc(String imgSrc) {
	        this.imgSrc = imgSrc;
	}


    
}
