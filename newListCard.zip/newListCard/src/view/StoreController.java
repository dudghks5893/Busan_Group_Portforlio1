package view;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import model.Store;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javafx.scene.input.MouseEvent;

public class StoreController implements Initializable {
	@FXML
	private HBox cardList;
	@FXML
	private ImageView img;
	@FXML
	private Label storeNameLabel;
	@FXML
	private Label storeInfoLabel;

	public void setData(Store store) {

		Image storeImage = new Image(getClass().getResourceAsStream(store.getImgSrc()));
	    img.setImage(storeImage);    
	    storeNameLabel.setText(store.getName());
	    storeInfoLabel.setText(store.getInfo());
	    }

	@Override
	public void initialize(URL location, ResourceBundle resources) {
				
	}
	  
	 @FXML
	    void mouseClick(MouseEvent event) throws IOException {
		 	cardList.getScene().getWindow().hide();
		 
		    Stage viewListCard = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("../view/.fxml"));
			Scene scene = new Scene(root);
			viewListCard.setTitle("����Ʈī�� ���ȭ��");
			viewListCard.setScene(scene);
			viewListCard.show();
			viewListCard.getScene().getWindow().hide();
		
	    }

}
