package view;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import model.Cafe;


public class CafeController implements Initializable{
	
	@FXML
	private ImageView img;
	@FXML
	private Label cafeNameLabel;
	@FXML
	private Label cafeInfoLabel;
	@FXML
	private HBox cardList;

	


	 public void setData(Cafe cafe) {

		 	Image cafeImage = new Image(getClass().getResourceAsStream(cafe.getImgSrc()));
	        img.setImage(cafeImage);
	        
	        cafeNameLabel.setText(cafe.getName());
	        cafeInfoLabel.setText(cafe.getInfo());
	    }

	@Override
	public void initialize(URL location, ResourceBundle resources) {
				
	}
	  
	 @FXML
	    void mouseClick(MouseEvent event) throws IOException {
		 	cardList.getScene().getWindow().hide();
		 
		    Stage viewListCard = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("../view/.fxml"));
			Scene scene = new Scene(root);
			viewListCard.setTitle("����Ʈī�� ���ȭ��");
			viewListCard.setScene(scene);
			viewListCard.show();
			viewListCard.getScene().getWindow().hide();
		
	    }

}


